.. _otherlang-reference-label:

使用其他语言调用ltp
=======================

如果您希望在本地使用除C++之外的其他语言调用LTP，我们针对常用语言对LTP进行了封装。

* Java: `ltp4j - Language Technology Platform for Java <https://github.com/HIT-SCIR/ltp4j>`_
* Python：`pyltp - the python extension for LTP <https://github.com/HIT-SCIR/pyltp>`_

