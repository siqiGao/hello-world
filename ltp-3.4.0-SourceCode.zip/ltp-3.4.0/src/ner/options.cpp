#include "ner/options.h"

namespace ltp {
namespace ner {

ModelOptions model_opt;
TrainOptions train_opt;
TestOptions  test_opt;
DumpOptions  dump_opt;

}       //  end for namespace ner
}       //  end for namespace ltp
