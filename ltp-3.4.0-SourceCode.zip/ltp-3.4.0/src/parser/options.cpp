#include "parser/options.h"

namespace ltp {
namespace parser {

ModelOptions     model_opt;
TrainOptions     train_opt;
TestOptions      test_opt;
FeatureOptions   feat_opt;

}   //  end for namespace parser
}   //  end for namespace ltp

