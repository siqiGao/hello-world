欢迎使用 pyltp

pyltp 是 `语言技术平台（Language Technology Platform, LTP） <https://github.com/HIT-SCIR/ltp>`_ 的 Python 封装。

如需了解 LTP 的详细信息，请参考 LTP 的 `文档 <https://github.com/HIT-SCIR/ltp>`_ 。
